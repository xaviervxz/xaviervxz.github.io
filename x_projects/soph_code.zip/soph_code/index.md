---
title: Code for Siblings
---

See the [files](https://github.com/xaviervxz/xaviervxz.github.io/tree/main/docs/x_projects/education/soph_code).
